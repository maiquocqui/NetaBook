// https://try.github.io/levels/1/challenges/2
// https://github.com/jekyll/jekyll/wiki/sites
// https://gist.github.com/coolaj86/1318304
// https://docs.npmjs.com/getting-started/publishing-npm-packages